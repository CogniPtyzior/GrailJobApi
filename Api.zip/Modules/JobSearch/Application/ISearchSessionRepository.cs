namespace GrailJobApi.Modules.JobSearch.Application;

public interface ISearchSessionRepository
{
    Task<SearchSession?> GetByUserIdAsync(Guid userId, bool includeCriteria = false, bool includeResults = false, CancellationToken cancellationToken = default);
    Task<SearchSession> GetOrCreateAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<SearchResult?> GetResultByIdAsync(Guid userId, Guid resultId, CancellationToken cancellationToken = default);

    Task RemoveCriteriaRangeAsync(IEnumerable<SearchCriterion> criteria);

    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
