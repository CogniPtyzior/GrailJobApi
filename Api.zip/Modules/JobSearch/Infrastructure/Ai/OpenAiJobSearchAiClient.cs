using GrailJobApi.Modules.JobSearch.Application;
using GrailJobApi.Shared.Ai;

namespace GrailJobApi.Modules.JobSearch.Infrastructure.Ai;

public sealed class OpenAiJobSearchAiClient(OpenAiStructuredChatClient client) : IJobSearchAiClient
{
    public async Task<IReadOnlyList<SearchResult>> ExecuteAsync(string candidateProfileText, IReadOnlyList<string> criteria, IReadOnlyList<string> filteredCompanyNames, CancellationToken cancellationToken = default)
    {
        if (!client.IsConfigured && client.UseMockFallback)
        {
            return BuildMockResults(criteria, filteredCompanyNames);
        }

        var schema = new Dictionary<string, object?>
        {
            ["type"] = "object",
            ["additionalProperties"] = false,
            ["properties"] = new Dictionary<string, object?>
            {
                ["companies"] = new Dictionary<string, object?>
                {
                    ["type"] = "array",
                    ["items"] = new Dictionary<string, object?>
                    {
                        ["type"] = "object",
                        ["additionalProperties"] = false,
                        ["properties"] = new Dictionary<string, object?>
                        {
                            ["companyName"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["jobTitle"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["offerUrl"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["offerDescription"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["location"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["workMode"] = new Dictionary<string, object?> { ["type"] = "string", ["enum"] = new[] { "Unknown", "OnSite", "Hybrid", "Remote" } },
                            ["salary"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["techStack"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["matchExplanation"] = new Dictionary<string, object?> { ["type"] = "string" },
                            ["relevanceScore"] = new Dictionary<string, object?> { ["type"] = "integer", ["minimum"] = 0, ["maximum"] = 100 }
                        },
                        ["required"] = new[] { "companyName", "jobTitle", "offerUrl", "offerDescription", "location", "workMode", "salary", "techStack", "matchExplanation", "relevanceScore" }
                    }
                }
            },
            ["required"] = new[] { "companies" }
        };

        var systemPrompt = "You are a deterministic job search matcher. Use the candidate profile text, search criteria, and filtered company names. Never return a company present in the filtered_company_names list. Return only JSON matching the schema. Do not invent impossible details, but provide concise professional values for the required fields.";
        var userPayload = JsonSerializer.Serialize(new
        {
            cv_text = candidateProfileText,
            criteria,
            filtered_company_names = filteredCompanyNames,
            instructions = new
            {
                relevance_score_range = "0 to 100",
                output_language = "English for structured fields",
                include_offer_url = true,
                include_location = true,
                include_work_mode = true,
                include_salary = true,
                include_tech_stack = true,
                include_match_explanation = true
            }
        });

        var response = await client.GetStructuredResponseAsync<JobSearchContract>("job_search_results", schema, systemPrompt, userPayload, cancellationToken);
        var nowUtc = DateTime.UtcNow;

        return response.Companies
            .Where(x => !string.IsNullOrWhiteSpace(x.CompanyName))
            .Where(x => !filteredCompanyNames.Contains(x.CompanyName, StringComparer.Ordinal))
            .GroupBy(x => x.CompanyName, StringComparer.Ordinal)
            .Select(group => group.OrderByDescending(x => x.RelevanceScore).First())
            .OrderByDescending(x => x.RelevanceScore)
            .Select(x => SearchResult.Create(x.CompanyName.Trim(), x.JobTitle.Trim(), x.OfferUrl.Trim(), x.OfferDescription.Trim(), x.Location.Trim(), ParseWorkMode(x.WorkMode), x.Salary.Trim(), x.TechStack.Trim(), x.MatchExplanation.Trim(), Math.Clamp(x.RelevanceScore, 0, 100), string.Empty, nowUtc))
            .ToArray();
    }

    private static IReadOnlyList<SearchResult> BuildMockResults(IReadOnlyList<string> criteria, IReadOnlyList<string> filteredCompanyNames)
    {
        var now = DateTime.UtcNow;
        var candidates = new[]
        {
            SearchResult.Create("Acme", "Senior Full Stack Developer", "https://example.com/jobs/123", "Product-oriented role with modern web stack.", "Paris", WorkMode.Hybrid, "55k-65k", ".NET 10, React, TypeScript, PostgreSQL", "Strong match for .NET and React criteria with hybrid setup.", 87, string.Empty, now.AddMinutes(-3)),
            SearchResult.Create("Northwind", "Backend .NET Engineer", "https://example.com/jobs/456", "Modern backend role with APIs and cloud services.", "Lyon", WorkMode.Remote, "50k-60k", ".NET 10, ASP.NET Core, PostgreSQL", "Good match for backend criteria and remote flexibility.", 81, string.Empty, now.AddMinutes(-2)),
            SearchResult.Create("Adventure Works", "Frontend Platform Engineer", "https://example.com/jobs/789", "React and TypeScript role in a product-focused team.", "Nantes", WorkMode.Hybrid, "48k-58k", "React, TypeScript, Vite, Design Systems", "Solid front-end opportunity aligned with React and TypeScript expectations.", 78, string.Empty, now.AddMinutes(-1))
        };

        return candidates
            .Where(x => !filteredCompanyNames.Contains(x.CompanyName, StringComparer.Ordinal))
            .ToArray();
    }

    private static WorkMode ParseWorkMode(string value)
        => Enum.TryParse<WorkMode>(value, ignoreCase: true, out var workMode) ? workMode : WorkMode.Unknown;

    private sealed record JobSearchContract([property: JsonPropertyName("companies")] JobSearchCompanyContract[] Companies);

    private sealed record JobSearchCompanyContract(
        [property: JsonPropertyName("companyName")] string CompanyName,
        [property: JsonPropertyName("jobTitle")] string JobTitle,
        [property: JsonPropertyName("offerUrl")] string OfferUrl,
        [property: JsonPropertyName("offerDescription")] string OfferDescription,
        [property: JsonPropertyName("location")] string Location,
        [property: JsonPropertyName("workMode")] string WorkMode,
        [property: JsonPropertyName("salary")] string Salary,
        [property: JsonPropertyName("techStack")] string TechStack,
        [property: JsonPropertyName("matchExplanation")] string MatchExplanation,
        [property: JsonPropertyName("relevanceScore")] int RelevanceScore);
}
